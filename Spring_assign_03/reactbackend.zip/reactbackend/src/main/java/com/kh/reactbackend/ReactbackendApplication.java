package com.kh.reactbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactbackendApplication.class, args);
	}

}
